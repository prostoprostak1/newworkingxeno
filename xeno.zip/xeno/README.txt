You must download Microsoft Visual C++ Redistributable & .NET 8.0 to run make Xeno run stable.
Open the links below to download them.

https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170
https://dotnet.microsoft.com/en-us/download/dotnet/8.0


If Xeno does not run at all after restarting computer. Please install .NET 8.0 and click on repair. This is a problem with .NET